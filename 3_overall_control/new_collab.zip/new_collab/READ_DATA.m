%freq at col1, temp at col2
%data_raw = heat2;
clear all
data_raw = csvread('cool3.csv');
temp = transpose(data_raw(:,1));
freq = transpose(data_raw(:,2));